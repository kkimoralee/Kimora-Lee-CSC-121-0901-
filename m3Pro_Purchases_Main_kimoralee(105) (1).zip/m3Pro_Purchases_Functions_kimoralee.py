#Kimora Lee
#Professor Seidi
#(CSC-121-0901)
# 
def book_display(books, authors, published, prices):
    print("{:<4} {:<40} {:<20} {:<10} {:<10}".format('Num', 'Book', 'Author', 'Year', 'Price'))
    print("-" * 80)
    for i in range(len(books)):
        print("{:<4} {:<40} {:<20} {:<10} {:<10}".format(i+1, books[i], authors[i], published[i], f'${prices[i]:.2f}'))

# Function to display information about the books the user selects
def show_purchase(book_nums, books, authors, published, prices):
    print("{:<40} {:<20} {:<10} {:<10}".format('Book', 'Author', 'Year', 'Price'))
    print("-" * 80)
    for num in book_nums:
        print("{:<40} {:<20} {:<10} {:<10}".format(books[num], authors[num], published[num], f'${prices[num]:.2f}'))

#Calculate the total price, tax (5%), and final cost
def totals(book_nums, prices):
    cost = sum([prices[num] for num in book_nums])
    tax = cost * 0.05
    total = cost + tax
    return cost, tax, total 