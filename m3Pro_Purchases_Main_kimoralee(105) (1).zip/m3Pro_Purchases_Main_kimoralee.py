#Kimora Lee
#Professor Seidi
#(CSC-121-0901)
# This is the Main module
from m3Pro_Purchases_Functions_kimoralee import book_display, show_purchase, totals

def main():
    # Lists containing book data (authors book pub date and price)
    authors = ['William Shakespeare', 'Charles Dickens', 'James Joyce', 'Earnest Hemingway', 'J.K. Rowling']
    books = ['Hamlet', 'A Tale of Two Cities', 'Ulysses', 'The Old Man and the Sea', 'Harry Potter and the Philosopher\'s Stone']
    published = [1601, 1859, 1922, 1952, 1997]
    prices = [14.52, 9.56, 19.97, 10.35, 16.62]

    # Display available books
    book_display(books, authors, published, prices)
    
    book_nums = []  #how many books does the user plan to buy
    
    # Allow the user to select books
    while True:
        try:
            choice = int(input("\nEnter number of the book you want to buy: ")) - 1
            if 0 <= choice < len(books):
                book_nums.append(choice)
            else:
                print("Invalid choice. Try again.")
        except ValueError:
            print("Please enter a valid number.")
        
        another = input("Would you like to purchase another book? (y for yes): ")
        if another.lower() != 'y':
            break
    
    # Display the purchased books
    show_purchase(book_nums, books, authors, published, prices)
    
    # Calculate totals
    cost, tax, total = totals(book_nums, prices)
    
    # Display total cost
    print("\nTotal price (cost of books + 5% tax):")
    print(f"Books cost before tax: ${cost:.2f}")
    print(f"Tax: ${tax:.2f}")
    print(f"Total after tax: ${total:.2f}")

# Run the program
if __name__ == "__main__":
    main()