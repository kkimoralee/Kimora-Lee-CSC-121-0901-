# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 19:03:36 2024

@author: kimora
"""
# Assignments requires good understanding of processing files, reading txt/string , using functions and exception handling
#  November 9, 2024
# CSC121 M5Pro
# Kimora Lee 
import csv 
import m3_functions as fn



# Function to show the menu to the user
def display_menu():
    print("\nMenu---------------")
    print("1) Display Book Inventory (Create Reports)")
    print("2) Purchase Book(s)")
    print("3) Display List of Purchases, Total Cost & Write Report")
    print("4) Exit")
    print("--------------------")

# Function to write book inventory to files
def write_inventory_to_files():
    # Write to envontory.txt
    with open('envontory.txt', 'w') as txt_file:
        txt_file.write("Num, Book, Author, Year, Price\n")
        for i in range(len(fn.authors)):
            txt_file.write(f"{i+1}, {fn.books[i]}, {fn.authors[i]}, {fn.published[i]}, ${fn.prices[i]:.2f}\n")

    # Write to env_report.csv
    with open('env_report.csv', 'w') as csv_file:
        csv_file.write("Book Name,Author,Year Pub.,Price\n")
        for i in range(len(fn.authors)):
            csv_file.write(f"{fn.books[i]},{fn.authors[i]},{fn.published[i]},${fn.prices[i]:.2f}\n")

# Function to write purchase details to a file
def write_purchases_to_csv(book_nums):
    with open('purchased.csv', 'w') as csv_file:
        csv_file.write("Book Name,Author,Year Pub.,Price\n")
        
        for i in book_nums:
            csv_file.write(f"{fn.books[i]},{fn.authors[i]},{fn.published[i]},${fn.prices[i]:.2f}\n")
        
        # Calculate totals
        cost, tax, total = fn.totals(book_nums)
        csv_file.write("\n")
        csv_file.write(f"Cost,,,${cost:.2f}\n")
        csv_file.write(f"Tax,,,${tax:.2f}\n")
        csv_file.write(f"Total,,,${total:.2f}\n")

# Main function to control the program
def main():
    # Keep the program running until user exits
    while True:
        # Show the menu
        display_menu()
        
        try:
            # Get user's choice
            choice = int(input("Enter your choice (1-4): "))
            
            # Option 1: Display the inventory and create reports
            if choice == 1:
                fn.book_display()  # Used function from m3_functions
                write_inventory_to_files()
              
            
            # Option 2: Let user purchase books
            elif choice == 2:
                book_nums = []
                run_again = 'y'
                while run_again.lower() == 'y':
                    book_num = input("\nEnter the number of the book you want to buy: ")
                    if book_num.isdigit():
                        book_num = int(book_num) - 1  # Adjust for 0-based indexing
                        if 0 <= book_num < len(fn.books):
                            book_nums.append(book_num)
                        else:
                            print("Invalid book number. Please enter a number between 1 and", len(fn.books))
                    else:
                        print("Invalid input. Please enter a numeric value.")
                    run_again = input("\nDo you want to buy another book? (y for yes): ")
                fn.show_purchase(book_nums)  # Used function from m3_functions
                cost, tax, total = fn.totals(book_nums)  # Used function from m3_functions
                print("\nTotal price (cost of book(s) + 5% tax):")
                print(f"Book(s) cost Before Tax: ${cost:,.2f}")
                print(f"Tax: ${tax:,.2f}")
                print(f"Total After Tax: ${total:,.2f}")
            
            # Option 3: Display purchase details and write to file
            elif choice == 3:
                book_nums = []
                run_again = 'y'
                while run_again.lower() == 'y':
                    book_num = input("\nEnter the number of the book you want to buy: ")
                    if book_num.isdigit():
                        book_num = int(book_num) - 1  # Adjust for 0-based indexing (for example 2 would be 1 and 3 would be 2 so on and so on)
                        if 0 <= book_num < len(fn.books):
                            book_nums.append(book_num)
                        else:
                            print("Invalid book number. Please enter a number between 1 and", len(fn.books))
                    else:
                        print("Invalid input. Please enter a numeric value.")
                    run_again = input("\nDo you want to buy another book? (y for yes): ")
                fn.show_purchase(book_nums)  # Used function from m3_functions
                write_purchases_to_csv(book_nums)
                print("\nPurchase details have been saved to 'purchased.csv'.")
                cost, tax, total = fn.totals(book_nums)  # Used function from m3_functions
                print("\nTotal price (cost of book(s) + 5% tax):")
                print(f"Book(s) cost Before Tax: ${cost:,.2f}")
                print(f"Tax: ${tax:,.2f}")
                print(f"Total After Tax: ${total:,.2f}")
            
            # Option 4: Exit program
            elif choice == 4:
                print("Exiting the program.")
                break
            
            # Display for invalid menu choices
            else:
                print("Invalid choice. Enter a number between 1 and 4.")
        
        # Handle non-numeric input
        except ValueError:
            print("Invalid input. Please enter a number.")

# Run the main function when the program starts
if __name__ == "__main__":
    main()