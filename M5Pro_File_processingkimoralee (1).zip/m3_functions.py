#function to display list of books

#lists
authors = ["William Shakespeare","Charles Dickens","James Joyce","Earnest Hemingway","J.K. Rowling"]

books = ["Hamlet","A Tale of Two Cities","Ulysses","The Old Man and the Sea","Harry Potter and the Philosopher’s Stone"]

published = [1601, 1859, 1922, 1952, 1997]
#list of book names

#list referencing book prices
prices =[14.52, 9.56, 19.97, 10.35, 16.62]

def book_display():
    '''
    function displays book information. Information retrieved from 4 different lists

    Returns
    -------
    None.

    '''


    print(f'{"Num":<5}{"Book":<60}{"Author":<30}{"Year":<8}{"Price"}')
    print('-'*120)

    for i in range(len(authors)):
            print(f'{i+1:<5}{books[i]:<60}{authors[i]:<30}{published[i]:<8}${prices[i]}')
    print('-'*120)

def show_purchase(book_nums):
    '''

    Parameters
    ----------
    book_nums : list , references index number for books user wants to purchase
    
    function displays information on the books selected

    Returns
    -------
    None.

    '''

    # create
    print()

    print(f'{"Book":<60}{"Author":<30}{"Year":<8}{"Price"}')
    print('-'*115)

    for i in book_nums:

        print(f'{books[i]:<60}{authors[i]:<30}{published[i]:<8}${prices[i]}')

def totals(book_nums):
    '''
    

    Parameters
    ----------
    book_nums : list , references index number for books user wants to purchase

    Returns
    -------
    cost : price total for books chosen
    tax : 5% tax on total price
    total : cost + tax

    '''

    pur_prices = []

    for i in book_nums:
        # get prices
        price = prices[i]

        pur_prices.append(price)

    # add cost of both books

    cost = sum(pur_prices)
    tax = cost * 0.05
    total = cost + tax

    return cost, tax, total
